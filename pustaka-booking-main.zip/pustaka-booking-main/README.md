# Pustaka Booking - WP3
Pustaka booking web programming 3

<table>
  <tr>
    <td>
      <b>Nim</b>
    </td>
    <td>19200077
    </td>
  </tr>
  <tr>
    <td>
      <b>Name</b>
    </td>
    <td>Adan Aidan Teras
    </td>
  </tr>
  <tr>
    <td>
      <b>Kelas</b>
    </td>
    <td>19.3E.07
    </td>
  </tr>
</table>

# User Login
 - Admin
    - Email : admin@gmail.com
    - Password : admin
 - Member
    - Email : member@gmail.com
    - Password : member 